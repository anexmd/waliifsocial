require("dotenv").config();
const crypto=require("crypto");
const http=require("http");
const express=require("express");
const cors=require("cors");
const helmet=require("helmet");
const rateLimit=require("express-rate-limit");
const mongoose=require("mongoose");
const jwt=require("jsonwebtoken");
const {Server}=require("socket.io");

const User=require("./models/User");
const Post=require("./models/Post");
const Follow=require("./models/Follow");
const Like=require("./models/Like");
const Comment=require("./models/Comment");
const Message=require("./models/Message");
const Notification=require("./models/Notification");
const Story=require("./models/Story");
const Group=require("./models/Group");

const app=express(), server=http.createServer(app);
const origins=(process.env.FRONTEND_URL||"").split(",").map(x=>x.trim()).filter(Boolean);
const io=new Server(server,{cors:{origin:origins.length?origins:true,methods:["GET","POST"]}});
app.use(helmet({contentSecurityPolicy:false}));
app.use(cors({origin:origins.length?origins:true}));
app.use(express.json({limit:"200kb"}));
app.use("/api/",rateLimit({windowMs:60000,limit:180}));
app.use(express.static("public"));

function validTelegram(initData){
  const p=new URLSearchParams(initData||""); const hash=p.get("hash");
  if(!hash||!process.env.TELEGRAM_BOT_TOKEN)return false;
  p.delete("hash");
  const data=[...p.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join("\n");
  const secret=crypto.createHmac("sha256","WebAppData").update(process.env.TELEGRAM_BOT_TOKEN).digest();
  const calc=crypto.createHmac("sha256",secret).update(data).digest("hex");
  return calc.length===hash.length&&crypto.timingSafeEqual(Buffer.from(calc),Buffer.from(hash));
}
function telegramUser(initData){
  if(!validTelegram(initData))throw new Error("Invalid Telegram initData");
  const p=new URLSearchParams(initData), age=Math.floor(Date.now()/1000)-Number(p.get("auth_date")||0);
  if(age<0||age>86400)throw new Error("Expired Telegram authentication");
  const u=JSON.parse(p.get("user")||"{}"); if(!u.id)throw new Error("Telegram user missing"); return u;
}
function sign(user){return jwt.sign({uid:String(user._id),telegramId:user.telegramId},process.env.JWT_SECRET,{expiresIn:"7d"});}
async function auth(req,res,next){
  try{
    const token=(req.headers.authorization||"").replace(/^Bearer\s+/,"");
    const d=jwt.verify(token,process.env.JWT_SECRET); const u=await User.findById(d.uid);
    if(!u)throw new Error(); req.user=u; next();
  }catch(e){res.status(401).json({error:"Authentication required"});}
}
function cleanUser(u){return {id:u._id,telegramId:u.telegramId,username:u.username,firstName:u.firstName,lastName:u.lastName,bio:u.bio,avatarUrl:u.avatarUrl,followers:u.followers,following:u.following};}

app.get("/api/health",(req,res)=>res.json({ok:true,service:"WaliifSocial",db:mongoose.connection.readyState===1?"connected":"disconnected"}));

app.post("/api/auth/telegram",async(req,res)=>{
  try{
    const u=telegramUser(req.body.initData);
    const user=await User.findOneAndUpdate(
      {telegramId:String(u.id)},
      {$set:{username:u.username||"",firstName:u.first_name||"",lastName:u.last_name||""}},
      {new:true,upsert:true,setDefaultsOnInsert:true}
    );
    res.json({token:sign(user),user:cleanUser(user)});
  }catch(e){res.status(401).json({error:e.message});}
});

app.get("/api/me",auth,async(req,res)=>res.json(cleanUser(req.user)));

app.patch("/api/me",auth,async(req,res)=>{
  const allowed=["bio","avatarUrl","coverUrl","language"];
  for(const k of allowed)if(req.body[k]!==undefined)req.user[k]=String(req.body[k]).slice(0,k==="bio"?500:1000);
  await req.user.save(); res.json(cleanUser(req.user));
});

app.get("/api/feed",auth,async(req,res)=>{
  const posts=await Post.find().sort({createdAt:-1}).limit(50).populate("author","username firstName lastName avatarUrl").lean();
  const ids=posts.map(p=>p._id);
  const liked=await Like.find({user:req.user._id,post:{$in:ids}}).select("post").lean();
  const set=new Set(liked.map(x=>String(x.post)));
  res.json(posts.map(p=>({...p,liked:set.has(String(p._id))})));
});

app.post("/api/posts",auth,async(req,res)=>{
  const text=String(req.body.text||"").trim(), mediaUrl=String(req.body.mediaUrl||"").trim();
  const mediaType=["none","image","video"].includes(req.body.mediaType)?req.body.mediaType:"none";
  if(!text&&!mediaUrl)return res.status(400).json({error:"Post cannot be empty"});
  const post=await Post.create({author:req.user._id,text,mediaUrl,mediaType});
  const full=await post.populate("author","username firstName lastName avatarUrl");
  io.emit("newPost",full);
  res.status(201).json(full);
});

app.post("/api/posts/:id/like",auth,async(req,res)=>{
  const post=await Post.findById(req.params.id); if(!post)return res.status(404).json({error:"Post not found"});
  const old=await Like.findOne({post:post._id,user:req.user._id});
  if(old){await old.deleteOne();post.likes=Math.max(0,post.likes-1);}
  else{
    await Like.create({post:post._id,user:req.user._id});post.likes++;
    if(String(post.author)!==String(req.user._id))await Notification.create({recipient:post.author,actor:req.user._id,type:"like",post:post._id,text:`${req.user.firstName||"Someone"} liked your post`});
  }
  await post.save(); res.json({liked:!old,likes:post.likes});
});

app.get("/api/posts/:id/comments",auth,async(req,res)=>{
  const rows=await Comment.find({post:req.params.id}).sort({createdAt:1}).limit(100).populate("user","username firstName lastName avatarUrl").lean();
  res.json(rows);
});

app.post("/api/posts/:id/comments",auth,async(req,res)=>{
  const text=String(req.body.text||"").trim(); if(!text)return res.status(400).json({error:"Comment is empty"});
  const post=await Post.findById(req.params.id); if(!post)return res.status(404).json({error:"Post not found"});
  const c=await Comment.create({post:post._id,user:req.user._id,text});post.comments++;await post.save();
  if(String(post.author)!==String(req.user._id))await Notification.create({recipient:post.author,actor:req.user._id,type:"comment",post:post._id,text:`${req.user.firstName||"Someone"} commented on your post`});
  res.status(201).json(await c.populate("user","username firstName lastName avatarUrl"));
});

app.post("/api/users/:id/follow",auth,async(req,res)=>{
  if(String(req.user._id)===String(req.params.id))return res.status(400).json({error:"You cannot follow yourself"});
  const target=await User.findById(req.params.id);if(!target)return res.status(404).json({error:"User not found"});
  const old=await Follow.findOne({follower:req.user._id,following:target._id});
  if(old){await old.deleteOne();req.user.following=Math.max(0,req.user.following-1);target.followers=Math.max(0,target.followers-1);}
  else{await Follow.create({follower:req.user._id,following:target._id});req.user.following++;target.followers++;await Notification.create({recipient:target._id,actor:req.user._id,type:"follow",text:`${req.user.firstName||"Someone"} followed you`});}
  await req.user.save();await target.save();res.json({following:!old,followers:target.followers});
});

app.get("/api/users/search",auth,async(req,res)=>{
  const q=String(req.query.q||"").trim(); if(!q)return res.json([]);
  const rx=new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),"i");
  const users=await User.find({$or:[{username:rx},{firstName:rx},{lastName:rx}]}).limit(30);
  res.json(users.map(cleanUser));
});

app.get("/api/users/:id",auth,async(req,res)=>{
  const u=await User.findById(req.params.id);if(!u)return res.status(404).json({error:"User not found"});
  const following=!!await Follow.exists({follower:req.user._id,following:u._id});
  const posts=await Post.find({author:u._id}).sort({createdAt:-1}).limit(30).lean();
  res.json({user:cleanUser(u),following,posts});
});

app.get("/api/stories",auth,async(req,res)=>{
  const rows=await Story.find({expiresAt:{$gt:new Date()}}).sort({createdAt:-1}).limit(50).populate("author","username firstName lastName avatarUrl").lean();
  res.json(rows);
});

app.post("/api/stories",auth,async(req,res)=>{
  const mediaUrl=String(req.body.mediaUrl||"").trim();if(!mediaUrl)return res.status(400).json({error:"Media URL required"});
  const expiresAt=new Date(Date.now()+24*60*60*1000);
  const story=await Story.create({author:req.user._id,mediaUrl,mediaType:req.body.mediaType==="video"?"video":"image",caption:String(req.body.caption||""),expiresAt});
  res.status(201).json(await story.populate("author","username firstName lastName avatarUrl"));
});

app.get("/api/reels",auth,async(req,res)=>{
  const rows=await Post.find({mediaType:"video"}).sort({createdAt:-1}).limit(50).populate("author","username firstName lastName avatarUrl").lean();
  res.json(rows);
});

app.get("/api/notifications",auth,async(req,res)=>{
  res.json(await Notification.find({recipient:req.user._id}).sort({createdAt:-1}).limit(50).populate("actor","username firstName lastName").lean());
});

app.get("/api/groups",auth,async(req,res)=>res.json(await Group.find({members:req.user._id}).sort({createdAt:-1}).limit(50).lean()));

io.use(async(socket,next)=>{
  try{
    const d=jwt.verify(socket.handshake.auth?.token,process.env.JWT_SECRET);
    const u=await User.findById(d.uid);if(!u)return next(new Error("Unauthorized"));
    socket.user=u;next();
  }catch(e){next(new Error("Unauthorized"));}
});
io.on("connection",socket=>{
  socket.on("sendMessage",async data=>{
    const to=String(data?.recipientId||"");const text=String(data?.text||"").trim();
    if(!to||!text||text.length>2000)return;
    const recipient=await User.findById(to);if(!recipient)return;
    const key=[String(socket.user._id),String(recipient._id)].sort().join(":");
    const m=await Message.create({conversationKey:key,sender:socket.user._id,recipient:recipient._id,text});
    const payload={id:m._id,sender:cleanUser(socket.user),recipientId:recipient._id,text:m.text,createdAt:m.createdAt};
    socket.emit("messageSent",payload);io.to(String(recipient._id)).emit("messageReceived",payload);
    await Notification.create({recipient:recipient._id,actor:socket.user._id,type:"message",text:`New message from ${socket.user.firstName||"a user"}`});
  });
  socket.join(String(socket.user._id));
});

async function start(){
  if(!process.env.MONGODB_URI||!process.env.TELEGRAM_BOT_TOKEN||!process.env.JWT_SECRET)throw new Error("MONGODB_URI, TELEGRAM_BOT_TOKEN and JWT_SECRET are required");
  await mongoose.connect(process.env.MONGODB_URI);
  const port=Number(process.env.PORT||5000);
  server.listen(port,()=>console.log(`WaliifSocial running on ${port}`));
}
start().catch(e=>{console.error(e);process.exit(1)});
