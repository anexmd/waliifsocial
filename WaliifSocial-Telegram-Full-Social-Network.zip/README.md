# WaliifSocial — Telegram Mini App

A full social-network starter designed to run inside Telegram.

## Included
- Home feed
- Stories UI
- Short-video/Reels feed
- Create post
- Likes/comments
- Follow/unfollow
- Profiles
- Search
- Notifications
- Real-time chat with Socket.IO
- Groups-ready data model
- Telegram Mini App authentication
- MongoDB persistence
- Telegram fullscreen support
- English / Afaan Oromoo / Amharic UI selector

## Architecture
Telegram -> Mini App frontend -> Node/Express API -> MongoDB
                                  -> Socket.IO
                                  -> media storage/provider

## Deployment
Frontend can be served by the same Node server or deployed separately.
If using Vercel for the frontend and Render/Railway for the API, set API_BASE_URL in `public/app.js`.

## Security
Never put TELEGRAM_BOT_TOKEN in frontend code. Telegram says initData must be validated on the server; do not trust initDataUnsafe for authentication.

## Production media
This starter stores media URLs rather than accepting large video files directly. Connect Cloudinary, S3-compatible storage, Firebase Storage, or another approved media provider before production.

## Moderation
Before public launch add report, block, content review, rate limits, spam detection, age/content controls, account deletion, privacy policy and terms.
