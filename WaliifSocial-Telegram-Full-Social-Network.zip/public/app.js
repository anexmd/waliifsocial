const API_BASE_URL="";
let token="",me=null,socket=null,activeRecipient=null;
const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
function show(id){document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x.id===id));document.querySelectorAll(".nav button[data-tab]").forEach(x=>x.classList.toggle("active",x.dataset.tab===id));window.scrollTo(0,0)}
function msg(t){$("status").textContent=t;$("status").classList.remove("hidden");setTimeout(()=>$("status").classList.add("hidden"),3500)}
async function api(path,opt={}){let h={"Content-Type":"application/json",...(opt.headers||{})};if(token)h.Authorization="Bearer "+token;let r=await fetch(API_BASE_URL+path,{...opt,headers:h}),d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||"Request failed");return d}
function tg(){return window.Telegram?.WebApp}
async function login(){
 const w=tg();if(!w){msg("Open WaliifSocial inside Telegram.");return}
 w.ready();w.expand();try{w.requestFullscreen?.()}catch{}
 const d=w.initData;if(!d)throw Error("Telegram authentication data is missing");
 const r=await api("/api/auth/telegram",{method:"POST",body:JSON.stringify({initData:d})});token=r.token;me=r.user;
 $("meAvatar").textContent=(me.firstName||"W").charAt(0).toUpperCase();connectSocket();await Promise.all([feed(),stories(),notifications(),profile()]);
}
function connectSocket(){socket=io(API_BASE_URL||undefined,{auth:{token}});socket.on("newPost",feed);socket.on("messageReceived",m=>{if(activeRecipient===m.sender.id)addMessage(m,false)})}
function userName(u){return esc([u.firstName,u.lastName].filter(Boolean).join(" ")||u.username||"User")}
function avatar(u){return `<div class="avatar">${(u?.firstName||u?.username||"U").charAt(0).toUpperCase()}</div>`}
async function feed(){
 const rows=await api("/api/feed");$("feedList").innerHTML=rows.length?rows.map(postHTML).join(""):'<div class="notice">No posts yet. Be the first to post.</div>';
}
function postHTML(p){return `<article class="post"><div class="author">${avatar(p.author)}<div><b>${userName(p.author)}</b><br><small>@${esc(p.author.username||"user")}</small></div></div>${p.text?`<div class="posttext">${esc(p.text)}</div>`:""}${p.mediaUrl?(p.mediaType==="video"?`<video class="media" controls playsinline src="${esc(p.mediaUrl)}"></video>`:`<img class="media" src="${esc(p.mediaUrl)}" alt="post media">`):""}<div class="actions"><button onclick="likePost('${p._id}')">♡ ${p.likes}</button><button onclick="comments('${p._id}')">💬 ${p.comments}</button><button onclick="sharePost('${p._id}')">↗ Share</button></div></article>`}
window.likePost=async id=>{await api("/api/posts/"+id+"/like",{method:"POST"});feed()}
window.comments=async id=>{const c=await api("/api/posts/"+id+"/comments");let text=c.map(x=>`${x.user.firstName||x.user.username}: ${x.text}`).join("\n");const v=prompt("Comments:\n"+(text||"No comments yet.")+"\n\nWrite a comment:");if(v?.trim()){await api("/api/posts/"+id+"/comments",{method:"POST",body:JSON.stringify({text:v})});feed()}}
window.sharePost=async id=>{const url=location.href+"?post="+id;if(tg()?.openTelegramLink)tg().openTelegramLink("https://t.me/share/url?url="+encodeURIComponent(url));else navigator.clipboard?.writeText(url);msg("Share link prepared")}
async function stories(){const rows=await api("/api/stories");$("stories").innerHTML=rows.map(s=>`<div class="story"><div class="avatar">${(s.author.firstName||"S").charAt(0)}</div><small>${userName(s.author)}</small></div>`).join("")||""}
async function reels(){const rows=await api("/api/reels");$("reelList").innerHTML=rows.length?rows.map(p=>`<div class="reel">${p.mediaUrl?`<video controls playsinline loop src="${esc(p.mediaUrl)}"></video>`:""}<div class="caption"><b>${userName(p.author)}</b><br>${esc(p.text)}</div></div>`).join(""):'<div class="notice">No short videos yet.</div>'}
async function notifications(){const rows=await api("/api/notifications");$("notificationList").innerHTML=rows.map(n=>`<div class="result">${avatar(n.actor||{})}<div>${esc(n.text)}<br><small>${new Date(n.createdAt).toLocaleString()}</small></div></div>`).join("")||'<div class="notice">No notifications.</div>'}
async function profile(){const u=await api("/api/me");me=u;$("profileView").innerHTML=`<div class="profile"><div class="profilehead">${avatar(u)}<div><h2>${userName(u)}</h2><div class="muted">@${esc(u.username||"user")}</div></div></div><p>${esc(u.bio||"No bio yet.")}</p><div class="stat"><b>${u.followers}<small> followers</small></b><b>${u.following}<small> following</small></b></div><button class="primary" onclick="editProfile()">Edit profile</button></div>`}
window.editProfile=async()=>{const bio=prompt("Bio",me.bio||"");if(bio!==null){await api("/api/me",{method:"PATCH",body:JSON.stringify({bio})});profile()}}
async function search(){const q=$("searchInput").value.trim();if(!q)return;const rows=await api("/api/users/search?q="+encodeURIComponent(q));$("searchResults").innerHTML=rows.map(u=>`<div class="result" onclick="openUser('${u.id}')">${avatar(u)}<div><b>${userName(u)}</b><br><small>@${esc(u.username||"user")}</small></div></div>`).join("")||'<div class="notice">No users found.</div>'}
window.openUser=async id=>{const d=await api("/api/users/"+id);$("userProfileView").innerHTML=`<div class="profile"><div class="profilehead">${avatar(d.user)}<div><h2>${userName(d.user)}</h2><div class="muted">@${esc(d.user.username||"user")}</div></div></div><p>${esc(d.user.bio||"")}</p><div class="stat"><b>${d.user.followers}<small> followers</small></b><b>${d.user.following}<small> following</small></b></div><button class="primary" id="followBtn">${d.following?"Unfollow":"Follow"}</button><h3>Posts</h3>${d.posts.map(p=>postHTML({...p,author:d.user})).join("")}</div>`;$("followBtn").onclick=async()=>{await api("/api/users/"+id+"/follow",{method:"POST"});openUser(id);};show("userProfile")}
async function publish(){const text=$("postText").value.trim(),mediaUrl=$("mediaUrl").value.trim(),mediaType=$("mediaType").value;if(!text&&!mediaUrl)return msg("Write something or add media.");await api("/api/posts",{method:"POST",body:JSON.stringify({text,mediaUrl,mediaType})});$("postText").value="";$("mediaUrl").value="";show("feed");feed()}
function addMessage(m,mine){const d=document.createElement("div");d.className="msg"+(mine?" mine":"");d.innerHTML=`<b>${esc(m.sender?.firstName||"User")}</b><br>${esc(m.text)}`;$("chatMessages").appendChild(d);$("chatMessages").scrollTop=$("chatMessages").scrollHeight}
document.addEventListener("DOMContentLoaded",async()=>{
 document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>{show(b.dataset.tab);if(b.dataset.tab==="reels")reels();if(b.dataset.tab==="notifications")notifications();if(b.dataset.tab==="profile")profile()});
 $("createBtn").onclick=()=>show("create");$("composer").onclick=()=>show("create");$("searchOpen").onclick=()=>show("search");$("searchBtn").onclick=search;$("searchInput").onkeydown=e=>{if(e.key==="Enter")search()};$("publish").onclick=publish;
 $("loadChat").onclick=()=>{activeRecipient=$("recipientId").value.trim();$("chatMessages").innerHTML="";show("chat")};
 $("chatForm").onsubmit=e=>{e.preventDefault();const t=$("chatText").value.trim();if(!t||!activeRecipient||!socket)return;if(socket.connected)socket.emit("sendMessage",{recipientId:activeRecipient,text:t});$("chatText").value=""};
 try{await login()}catch(e){msg(e.message)}
});
