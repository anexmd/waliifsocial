const mongoose=require("mongoose");
const NotificationSchema=new mongoose.Schema({
  recipient:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true,index:true},
  actor:{type:mongoose.Schema.Types.ObjectId,ref:"User"},
  type:{type:String,enum:["like","comment","follow","message","system"],required:true},
  post:{type:mongoose.Schema.Types.ObjectId,ref:"Post",default:null},
  text:{type:String,required:true},
  read:{type:Boolean,default:false}
},{timestamps:true});
module.exports=mongoose.model("Notification",NotificationSchema);
