const mongoose=require("mongoose");
const PostSchema=new mongoose.Schema({
  author:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true,index:true},
  text:{type:String,default:"",maxlength:3000},
  mediaUrl:{type:String,default:""},
  mediaType:{type:String,enum:["none","image","video"],default:"none"},
  likes:{type:Number,default:0}, comments:{type:Number,default:0}, shares:{type:Number,default:0}
},{timestamps:true});
module.exports=mongoose.model("Post",PostSchema);
