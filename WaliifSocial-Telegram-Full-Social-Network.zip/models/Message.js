const mongoose=require("mongoose");
const MessageSchema=new mongoose.Schema({
  conversationKey:{type:String,required:true,index:true},
  sender:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true},
  recipient:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true},
  text:{type:String,required:true,maxlength:2000}
},{timestamps:true});
module.exports=mongoose.model("Message",MessageSchema);
