const mongoose = require("mongoose");
const UserSchema = new mongoose.Schema({
  telegramId:{type:String,unique:true,index:true,required:true},
  username:{type:String,default:""}, firstName:{type:String,default:""}, lastName:{type:String,default:""},
  bio:{type:String,default:""}, avatarUrl:{type:String,default:""}, coverUrl:{type:String,default:""},
  language:{type:String,enum:["en","om","am"],default:"en"},
  followers:{type:Number,default:0}, following:{type:Number,default:0},
  role:{type:String,enum:["user","admin"],default:"user"}
},{timestamps:true});
module.exports=mongoose.model("User",UserSchema);
