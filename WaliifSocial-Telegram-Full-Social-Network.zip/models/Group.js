const mongoose=require("mongoose");
const GroupSchema=new mongoose.Schema({
  name:{type:String,required:true,maxlength:100},
  description:{type:String,default:"",maxlength:500},
  owner:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true},
  members:[{type:mongoose.Schema.Types.ObjectId,ref:"User"}],
  avatarUrl:{type:String,default:""}
},{timestamps:true});
module.exports=mongoose.model("Group",GroupSchema);
