const mongoose=require("mongoose");
const StorySchema=new mongoose.Schema({
  author:{type:mongoose.Schema.Types.ObjectId,ref:"User",required:true,index:true},
  mediaUrl:{type:String,required:true},
  mediaType:{type:String,enum:["image","video"],default:"image"},
  caption:{type:String,default:""},
  expiresAt:{type:Date,required:true,index:true}
},{timestamps:true});
module.exports=mongoose.model("Story",StorySchema);
